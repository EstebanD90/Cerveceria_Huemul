const MenuItems = [
    {
        title: 'Home',
        url: '#',
        cName: 'nav-links'
    },
    {
        title: 'Productos',
        url: '#',
        cName: 'nav-links'
    },
    {
        title: 'Servicios',
        url: '#',
        cName: 'nav-links'
    },
    {
        title: 'Quienes Somos',
        url: '#',
        cName: 'nav-links'
    },
    {
        title: 'Contacto',
        url: '#',
        cName: 'nav-links'
    },
    {
        title: 'Carrito',
        url: '#',
        cName: 'nav-links'
    },

]