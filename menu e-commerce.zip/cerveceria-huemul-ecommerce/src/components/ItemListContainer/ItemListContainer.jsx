

export function ItemListContainer() {
    return (
        <div>
            Aca va el listado de productos
        </div>

    )
}